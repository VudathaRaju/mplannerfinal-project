export const environment = {
  baseUrl: "https://vudatha.work",
  // baseUrl: 'http://localhost:3013',
  production: true,
  VAPID_PUBLIC_KEY: "BEf-TmieLZZ23RTDIE2ALphXd3vvHlbjaQrCNx01UIVcZJ99M2vAMU0BC4eivlM2Vb_3NqDi2Ge2n_s4cHQM1Go"
};
