iziToast.settings({
    timeout: 6000,
    resetOnHover: true,
    transitionIn: 'flipInX',
    transitionOut: 'flipOutX',
    position: 'topRight',
    onOpening: function () {
    },
    onClosing: function () {
    }
});
